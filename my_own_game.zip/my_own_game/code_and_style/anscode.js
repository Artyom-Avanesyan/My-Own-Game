// function myFunction(a) {
//     // location.href="https://example.com/";
//     switch (a){
//         case 1: alert(1);
//         break;
//         case 2: alert(2);
//         break;
//         case 3: alert(3);
//         break;
//         case 4: alert(4);
//         break;
//         case 5: alert(5);
//         break;
//     }
    
// document.getElementById("demo").innerHTML = "Paragraph changed.";
// }

// function colrChange(b){
// if(b == 0){ document.getElementById("bottom").style.webkitTextFillColor = "rgb(255,255,255)";}
// else if(b == 1){ document.getElementById("bottom").style.webkitTextFillColor = "rgb(0,0,0)";}
// }
// let arr = [localStorage.getItem("theme"), localStorage.getItem("question")];
// windows.onload = function updute(){


// }